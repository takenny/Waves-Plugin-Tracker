// Get the link elementes
var plugins = document.getElementById("plugins-link");
var bundles = document.getElementById("bundles-link");
// Get the hover menu elements
var pluginMenu = document.getElementsByClassName("dropdown-content")[0];
var bundlesMenu = document.getElementsByClassName("dropdown-content")[1];

// Mouseover and mouse out listeners for the plugins  hover menu
plugins.onmouseover = function(){showPluginMenu(pluginMenu)};
plugins.onmouseout = function(){setTimeout(showPluginMenu(pluginMenu),1000)};
pluginMenu.onmouseover = function(){showPluginMenu(pluginMenu)};
pluginMenu.onmouseout = function(){hidePluginMenu(pluginMenu)};

// Mouse over and mouse out listeners for the bundle menu
bundles.onmouseover = function(){showPluginMenu(bundlesMenu)};
bundles.onmouseout = function(){setTimeout(showPluginMenu(bundlesMenu),1000)};
bundlesMenu.onmouseover = function(){showPluginMenu(bundlesMenu)};
bundlesMenu.onmouseout = function(){hidePluginMenu(bundlesMenu)};

// Show the plugin menu/ bundle hover menu.
// x - this is the element that is being shown. Both elements are hidden by default
// x can be either pluginMenu or bundleMenu
function showPluginMenu(x) {
    //document.getElementsByClassName("dropdown-content").style.display = "block";
    pluginMenu.style.display="none";
    bundlesMenu.style.display="none";
    x.style.display="block";
}

// This hides both the bundle and plugin hover menu
function hidePluginMenu() {
    //document.getElementsByClassName("dropdown-content").style.display = "none";
    pluginMenu.style.display="none";
    bundlesMenu.style.display="none";
}