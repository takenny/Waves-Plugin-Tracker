from django.db import models
from django.contrib.auth.models import User
from datetime import date
from django.db.models import UniqueConstraint


class Product(models.Model):
    # This is the product SKUID. It is also used as the id in the database
    id = models.IntegerField(primary_key=True)
    # The product name
    name = models.CharField(max_length=100, unique=True)
    # Url to the page in the Waves Site
    page_url = models.CharField(max_length=200)
    # Url for the small version of the image). This loads faster then the full size image
    icon_img_url = models.CharField(max_length=200)
    # Url for the full size image. This loads slower, but is higher resolution
    full_img_url = models.CharField(max_length=200, null=True, blank=True)
    # The market value of the product
    msrp = models.DecimalField(max_digits=15, decimal_places=2)
    # The number of reviews that this product has received
    review_number = models.IntegerField()
    # The rating for this product
    rating = models.DecimalField(max_digits=4, decimal_places=2)
    # This is to differentiate between plugin and bundle.
    type = models.CharField(max_length=20)

    # To string method. Prints out the name of the product
    def __str__(self):
        return self.name

    # This is used to get the Price data object for the current date related to the product object
    # It returns a PriceDate Object
    def get_price(self):
        return ProductPrice.objects.get(product__id=self.id, price_date=date.today())

    # This gets the current price for the current data related to the calling product object
    # It returns a float
    def get_current_price(self):
        product_price = ProductPrice.objects.get(product__id=self.id, price_date=date.today())
        return product_price.current_price

    # This gets today's coupon price related to the calling product object
    # It return a float
    def get_coupon_price(self):
        product_price = ProductPrice.objects.get(product__id=self.id, price_date=date.today())
        return product_price.coupon_price

    # This gets whether the calling product object is enabled or not
    # This returns a bool
    def get_enabled(self):
        if self.type == 'plugin':
            plugin = Plugin.objects.get(product=self)
            enabled = plugin.enabled
        else:
            enabled = True
        return enabled


# The plugin class adds information to the products that are plugins
class Plugin(models.Model):
    # This is a Product object for that holds the product information
    product = models.OneToOneField(
        Product,
        on_delete=models.CASCADE,
        primary_key=True,
    )
    # Whether the product is enabled or not
    # Plugins that are disabled are only available for purchase as part of a bundle
    enabled = models.BooleanField()
    
    def __str__(self):
        return self.product.name


# Adds information for products that are bundles
class Bundle(models.Model):
    # The product object
    product = models.OneToOneField(
        Product,
        models.CASCADE,
        primary_key=True,
    )
    # This is a list of plugins that are part of that bundle.
    plugins = models.ManyToManyField(
        Plugin,
        related_name="Bundle",
        db_table="index_bundleitem",
    )

    def __str__(self):
        return self.product.name


# Holds plugins that are in user's wishlist
class Wishlist(models.Model):
    # Whether to send notification or not
    send_notification = models.BooleanField()
    # Is the item purchased or not
    is_purchased = models.BooleanField()
    # User who created the wishlist
    users = models.ForeignKey(
        User,
        on_delete=models.CASCADE
    )
    # The product that the user is saving to the wishlist
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE
    )

    class Meta:
        default_related_name = "wishlists"


# This hold the price data for a specific day
class ProductPrice(models.Model):
    # The current price of the item
    current_price = models.DecimalField(max_digits=6, decimal_places=2)
    # If the item has a coupon code available, it will have a coupon price
    # Ig the item does not have a coupon conde available, then the coupon price is 0
    coupon_price = models.DecimalField(max_digits=6, decimal_places=2)
    # The data that this price is recorded
    # This is added automatically when the price is added to the database
    price_date = models.DateField(auto_now_add=True)
    # Some items will have a badge such as "new"
    # items that dont have a badge are represented as '' in the models.
    badge = models.CharField(max_length=60, null=True, blank=True)
    # The product whose price is being recorded
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE
    )

    class Meta:
        default_related_name = "product_prices"
        ordering = ['-current_price']
        constraints = [
            UniqueConstraint(fields=['product', 'price_date'], name='unique_price_date')
        ]

    def __str__(self):
        return str(self.price_date) + ": " + self.product.name


# The product category
class ProductCategory(models.Model):
    product = models.OneToOneField(
        Product,
        on_delete=models.CASCADE,
        primary_key=True
    )
    category = models.CharField(max_length=100)

    class Meta:
        default_related_name = 'product_categories'

    def __str__(self):
        return self.category
