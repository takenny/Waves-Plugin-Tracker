from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt

from . import models
from django.db.models import Q
from django.views.generic import ListView
import datetime
from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.http import JsonResponse
from django.views.generic import TemplateView
from .models import ProductPrice

# This is the number of items per page
NUM_PER_PAGE = 15


# Create your views here
# This is the View for the home page
# request: this is in every view.
def home(request):
    # Hold the data for the plugins. This is used to join the data from multiple tables
    plugin_dict = {}

    # Query to get the product price data.
    # This only grabs the products with a badge
    plugin_price = models.ProductPrice.objects.filter(price_date=datetime.date.today()).exclude(badge='')

    # Loop to group the plugins by badge
    for i in range(len(plugin_price)):
        if plugin_price[i].badge in plugin_dict:
            plugin_dict[plugin_price[i].badge].append(plugin_price[i])
        else:
            plugin_dict.update({plugin_price[i].badge: [plugin_price[i]]})

    # Data being sent to the homepage
    context = {
        "plugin_list": plugin_dict,
        'numbers': range(1, 6),  # This is used to display the star rating on the homepage
    }
    return render(request, 'home.html', context)


# This is the Wishlist view. Users can only access the page if they are logged in.
# username: the username of the person logged in.
@login_required()
def wishlist(request, user_name):
    context = {}

    # Get the wishlist objects for that belong to the person that is logged in.
    wishlist = models.Wishlist.objects.filter(users__username=user_name
                                              ).order_by('product__name')

    # Pagination Related stuff.
    # If no page number is given then by default the page is 1.
    page = request.GET.get('page', 1)
    wishlist_paginator = Paginator(wishlist, NUM_PER_PAGE)
    try:
        wishlist = wishlist_paginator.page(page)
    except PageNotAnInteger:
        wishlist = wishlist.page(1)
    except EmptyPage:
        wishlist = wishlist_paginator.page(wishlist_paginator.num_pages)

    context = {
        'wishlist': wishlist,
        'numbers': range(1, 6)  # Used for the star rating
    }

    return render(request, 'wishlist.html', context)


# Plugin view
# plugin_name: the name of the plugin. the name is used to match get the data from the database
def plugin(request, plugin_name):
    qs = []
    # get the plugin data.
    plugin = models.Product.objects.filter(name__iexact=plugin_name).get()
    # get the product category
    c = models.ProductCategory.objects.filter(product=plugin).get()
    # get the first 5 items with the same category
    related = models.ProductCategory.objects.filter(category=c.category).order_by('product__rating')[:5]

    # calculate stuff
    # Get all the current prices and coupon prices from the database.
    price = models.ProductPrice.objects.filter(product__name__iexact=plugin_name)
    # This is the lowest the price has ever been.
    global_low = price[0].current_price
    # This is the lowest the price has been in the last 30 days
    local_low = price[0].current_price

    # variables used to calculate the local and global average
    global_avg = 0  # This is the average of all the prices for this product in the database
    local_avg = 0   # This is the average of all the prices in the database that are from the last 30 days.
    global_counter = 0
    local_counter = 0
    # This is the lowest date for a price for the local min and local average.
    local_limit = datetime.date.today() + datetime.timedelta(-30)

    for item in price:
        x = 0
        # if it has a coupon price then use the coupon price
        if item.coupon_price != 0:
            x = item.coupon_price
        else:
            x = item.current_price
        qs.append((item.price_date, x))
        # if its within the local limit use it in the local average and local min calculations.
        if item.price_date > local_limit:
            if x < local_low:
                local_low = x
            local_avg += x
            local_counter += 1
        if x < global_low:
            global_low = x
        global_counter += 1
        global_avg += x
    qs.sort()
    x_axis, y_axis = zip(*qs)
    context = {
        'plugin': plugin,
        'numbers': range(1, 6),
        'related': related,
        'local_low': local_low,
        'global_low': global_low,
        # divide by the number of items within the local limit and then round to 2 decimal places
        'local_avg': round(local_avg/local_counter, 2),
        # divide by the number of items and then round to 2 decimal paces.
        'global_avg': round(global_avg/global_counter, 2),
        'x_axis': x_axis,
        'y_axis': y_axis,
    }
    return render(request, 'plugin.html', context)


# Bundle page view
# bundle_name: this is the name of the bundle. It is used to get the data diplayed in the template
def bundle(request, bundle_name):
    qs = []
    # This is here because some bundle names were causing issues.
    if bundle_name.find('.'):
        plugin_name = bundle_name[:-2]
    # Get the bundle data
    bundle = models.Product.objects.filter(name__iexact=bundle_name).get()

    # Get the plugins that are part of the bundle
    plugins = models.Bundle.objects.filter(product=bundle).get()
    related = plugins.plugins.all()

    # calculate stuff
    # This is pretty much the same as the plugin calculations
    price = models.ProductPrice.objects.filter(product__name__iexact=bundle_name)
    global_low = price[0].current_price
    local_low = price[0].current_price
    global_avg = 0
    local_avg = 0
    global_counter = 0
    local_counter = 0
    local_limit = datetime.date.today() + datetime.timedelta(-30)

    for item in price:
        x = 0
        if item.coupon_price != 0:
            x = item.coupon_price
        else:
            x = item.current_price
        qs.append((item.price_date, x))
        if item.price_date > local_limit:
            if x < local_low:
                local_low = x
            local_avg += x
            local_counter += 1
        if x < global_low:
            global_low = x
        global_counter += 1
        global_avg += x
    qs.sort()
    x_axis, y_axis = zip(*qs)
    # calculate price if bought individually
    # This this calculates using the lowest price for each plugin
    # If there is a coupon price it uses the coupon price, else it uses the current price.
    # The values are all added and put in the context
    individual_price = 0
    for item in related:
        if item.enabled:
            if item.product.get_coupon_price() == 0:
                individual_price += item.product.get_current_price()
            else:
                individual_price += item.product.get_coupon_price()

    context = {
        'bundle': bundle,
        'numbers': range(1, 6),
        'related': related,
        'local_low': local_low,
        'global_low': global_low,
        'local_avg': round(local_avg / local_counter, 2),
        'global_avg': round(global_avg / global_counter, 2),
        'individual_price': individual_price,
        'x_axis': x_axis,
        'y_axis': y_axis,
    }
    print(qs)
    return render(request, 'bundle.html', context)


# Profile page view
# user_name: name of the user that is logged in.
@login_required()
def profile(request, user_name):
    # list of plugins that the login user owns
    bought = models.Wishlist.objects.filter(users__username=user_name, is_purchased=True)
    # list of plugins that the login has added to the wishlist, but is not owned by the user.
    want = models.Wishlist.objects.filter(users__username=user_name, is_purchased=False)

    context = {
        'numbers': range(1, 6),  # Used to display the star rating
        'bought': bought[:6],  # get only the first 5 in the bought list
        'want': want[:6]  # get only the first five in the want list
    }
    return render(request, 'profile.html', context)


# Search page view
class SearchResultsView(ListView):
    # Use the product category table since we are also searching by category
    model = models.ProductCategory
    # Use the search.html template
    template_name = 'search.html'

    # Get the search results
    def get_queryset(self):
        # object list holds all the search results.
        object_list = []
        # get the search word.
        query = self.request.GET.get('q', '')

        # In order to differentiate between array i added either an ':p' or ':q' to differentiate between only
        # searching for plugins or only search through the bundles. The third option is that it can have nothing
        # added to the end of the search word. There are better ways of doing this, but this was the best way
        # I could come up with at the time.
        query_arr = []  # This is used to separate the query part from the identifier part and holds both parts
        # If it has an identifier then split the search word from the identifier.
        if query.find(':') != -1:
            query_arr = query.split(':')
            query = query_arr[0]  # This is the search word.

        # If the query had an identifier...
        if len(query_arr) == 2:
            # if it has a plugin identifier...
            if query_arr[1] == 'p':
                object_list = models.ProductCategory.objects.filter(
                    # Search by product category, product name, and product type plugin.
                    Q(product__type__contains='plugin') & (Q(category__icontains=query) | Q(product__name__icontains=query))
                ).order_by('product__name')  # sort the results by the product name
            # if it has a bundle identifier.
            elif query_arr[1] == 'b':
                object_list = models.ProductCategory.objects.filter(
                    Q(product__type__contains='bundle') & (Q(category__icontains=query) | Q(product__name__icontains=query))
                ).order_by('product__name')
        else:
            # If it has no identifier, search both bundles and plugins.
            object_list = models.ProductCategory.objects.filter(
                Q(category__icontains=query) | Q(product__name__icontains=query)
            ).order_by('product__name')

        return object_list

    # This is used to get other data that appears on the page.
    def get_context_data(self):
        # get the search results so it can be added to the context.
        object_list = self.get_queryset()
        # get the plugin categories. This is used for the side bar
        plugins = models.ProductCategory.objects.filter(product__type='plugin').values('category').distinct()
        plugin_categories = []  # list to hold the plugin categories
        bundle_categories = []  # list to hold the bundle categories

        # filter out the null results
        for plugin in plugins:
            for key, value in plugin.items():
                if value != '':
                    plugin_categories.append(value)
        # get the bundle categories. This is used for the side bar
        bundles = models.ProductCategory.objects.filter(product__type='bundle').values('category').distinct()
        # add values to the bundle categories list.
        for bundle in bundles:
            for key, value in bundle.items():
                bundle_categories.append(value)

        # Pagination code.
        # Get the page number. If no page number is provided use page 1 as the default value.
        page = self.request.GET.get('page', 1)
        search_paginator = Paginator(object_list, NUM_PER_PAGE)
        try:
            object_list = search_paginator.page(page)
        except PageNotAnInteger:
            object_list = search_paginator.page(1)
        except EmptyPage:
            object_list = search_paginator.page(search_paginator.num_pages)

        context = {
            'plugin_categories': plugin_categories,
            'bundle_categories': bundle_categories,
            'object_list': object_list,
        }
        return context


#######################################################################
#                       Backend Views                                 #
#######################################################################
'''
These views are used to send data to the templates when AJAX requests are
made.
'''

'''
Add to favorites view.
Despite it's name, it can either add an item to wishlist or remove the item from the wishlist.
This requires the form to send three pieces of data:
username: the name of user that is logged in
plugin: the plugin or bundle that is being added or removed.
exists: if the plugin/bundle already exists in the user's wishlist
'''
@login_required
def add_favorites(request):
    """add plugin to favorites"""
    username = request.GET.get('username')  # get the username
    plugin = request.GET.get('plugin')  # get the plugin/bundle name
    exists = request.GET.get('exists')  # get if the bundle exists or not

    # if the plugin/ bundle exist in the users wishlist, then delete it from the database, else add it to the database
    if exists == 'true':
        wish = models.Wishlist.objects.get(users__username=username, product__id=plugin)
        wish.delete()
        added = False
    else:
        user = User.objects.get(username=username)
        product = models.Product.objects.get(id=plugin)
        wish = models.Wishlist(send_notification=False, is_purchased=False, users=user, product=product)
        wish.save()
        added = True

    # added: is a boolean value. If the plugin/bundle was added then added is true, else it's false
    response = {
        'added': added
    }
    # Return the response.
    return JsonResponse(response)


'''
set favorites button in the plugin or bundle page
This sets the button if the user is logged in.
This takes in two pieces of data:
username: the name of the user that is logged in
plugin: the plugin/bundle that is being used.
'''
@login_required
def setFavoritesButton(request):
    '''Set the favorites button'''
    username = request.GET.get('username')  # get the username
    plugin = request.GET.get('plugin')  # get the plugin/ bundle name
    # check if plugin/bundle is in the users wishlist
    added = models.Wishlist.objects.filter(users__username=username, product__id=plugin).exists()

    # if it exists added is true, else its false
    response = {
        'added': added
    }
    return JsonResponse(response)


'''
Remove item from wishlist
This is used in the Wishlist page
'''
@login_required
def remove_from_wishlist(request):
    username = request.GET.get('username')  # get the username of the logged in user
    plugin = request.GET.get('plugin')  # get the plugin/bundle name

    # Get the wishlist item and delete it
    wish = models.Wishlist.objects.get(users__username=username, product__id=plugin)
    wish.delete()

    # This is trash data, but AJAX needs a response. It isnt used for anything
    response = {
        'deleted': 'deleted',
    }
    return JsonResponse(response)


'''
Add to purchased.
THis modifies the database to change the wishlist item from not purchased to purchased
For this it request the username and the product name
'''
@login_required
def add_to_purchased(request):
    username = request.GET.get('username')  # get the username
    plugin = request.GET.get('plugin')  # get the product name

    # get the wishlist item.
    wish = models.Wishlist.objects.get(users__username=username, product__id=plugin)
    wish.is_purchased = True  # change Purchased to true
    wish.save()  # Save the changes

    # AJAX requires a response, but no response is needed so I sent trash data that isn't used for anything.
    response = {
        'updated': 'updated',
    }

    return JsonResponse(response)


# data visualizer for charts
# implementation of a charts to be utilized in graph displays
class dataview(TemplateView):
    template_name = 'chart.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        queryset = ProductPrice.objects.values('price_date', 'coupon_price')
        queryset = queryset.order_by('price_date')
        context["qs"] = queryset
        # context["qs"] = ProductPrice.objects.all()
        return context


'''
Send notification
Modifies a wishlist item to toggle the send notification field.
'''
def send_notification(request):
    username = request.GET.get('username')
    plugin = request.GET.get('plugin')

    wish = models.Wishlist.objects.get(users__username=username, product__id=plugin)
    if wish.send_notification:
        wish.send_notification = False
        updated = False
    else:
        wish.send_notification = True
        updated = True
    wish.save()

    response = {
        'updated': updated,
    }
    return JsonResponse(response)


# @csrf_exempt
# def plugin_data(request):
#     # some data
