from django.contrib import admin
from import_export import resources
from import_export.fields import Field
from import_export.admin import ImportExportModelAdmin
from . import models


# Register your models here.
class ProductResource(resources.ModelResource):
    name = Field(attribute='name', column_name='DocumentName')
    page_url = Field(attribute='page_url', column_name='DocumentUrlPath')
    icon_img_url = Field(attribute='icon_img_url', column_name='Icon')
    full_img_url = Field(attribute='full_img_url', column_name='Full')
    id = Field(attribute='id', column_name='SKUID')
    msrp = Field(attribute='msrp', column_name='SKU_MSRP')
    review_number = Field(attribute='review_number', column_name='ReviewsTotal')
    rating = Field(attribute='rating', column_name='Rating')
    type = Field(attribute='type', column_name='Type')

    class Meta:
        model = models.Product


class BundleResource(resources.ModelResource):  # for the bundles

    class Meta:
        model = models.Bundle
        import_id_fields = ('product', )


class WishlistResource(resources.ModelResource):  # wishlist
    class Meta:
        model = models.Wishlist


class ProductPriceResource(resources.ModelResource):
    current_price = Field(attribute='current_price', column_name='SKUPrice')
    coupon_price = Field(attribute='coupon_price', column_name='CouponPrice')
    price_date = Field(attribute='date', column_name='Date')
    badge = Field(attribute='badge', column_name='BadgeText')
    product = Field(attribute='product_id', column_name='SKUID')

    class Meta:
        model = models.ProductPrice


class ProductCategoryResource(resources.ModelResource):
    category = Field(attribute='category', column_name='GSFCategory')
    product = Field(attribute='product_id', column_name='SKUID')

    class Meta:
        model = models.ProductCategory
        import_id_fields = ('product',)


class PluginResource(resources.ModelResource):
    product = Field(attribute='product_id', column_name='SKUID')
    enabled = Field(attribute='enabled', column_name='SKUEnabled')

    class Meta:
        model = models.Plugin
        import_id_fields = ('product',)


class WishlistAdmin(ImportExportModelAdmin):
    list_display = ('users', 'product', 'is_purchased', 'send_notification')
    resource_class = WishlistResource


class BundleAdmin(ImportExportModelAdmin):
    resource_class = BundleResource


class ProductAdmin(ImportExportModelAdmin):
    list_display = ('id', 'name', 'msrp', 'review_number', 'rating')
    list_filter = ('type',)
    search_fields = ('name', 'type')
    resource_class = ProductResource


class ProductPriceAdmin(ImportExportModelAdmin):
    list_display = ('price_date', 'product', 'current_price', 'coupon_price')
    resource_class = ProductPriceResource


class ProductCategoryAdmin(ImportExportModelAdmin):
    list_display = ('product', 'category')
    list_filter = ('category', )
    resource_class = ProductCategoryResource


class PluginAdmin(ImportExportModelAdmin):
    list_display = ('product', 'enabled')
    list_filter = ('enabled', )
    resource_class = PluginResource


admin.site.register(models.Product, ProductAdmin)
admin.site.register(models.Bundle, BundleAdmin)
admin.site.register(models.Wishlist, WishlistAdmin)
admin.site.register(models.ProductPrice, ProductPriceAdmin)
admin.site.register(models.ProductCategory, ProductCategoryAdmin)
admin.site.register(models.Plugin, PluginAdmin)
