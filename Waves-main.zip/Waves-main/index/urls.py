from django.urls import path

from . import views

'''
This is how the urls are generated
path(path pattern, path view, path name)
'''

urlpatterns = [
    # Homepage url
    path('', views.home, name="home"),
    # Wishlist page url
    path('profile/<str:user_name>/wishlist/', views.wishlist, name="wishlist"),
    # Plugin page url
    path('plugin/<str:plugin_name>', views.plugin, name="plugin"),
    # Bundle page url
    path('bundle/<str:bundle_name>', views.bundle, name="bundle"),
    # Profile page url
    path('profile/<str:user_name>', views.profile, name='profile'),
    # Search Page url
    path('search/', views.SearchResultsView.as_view(), name='search_results'),
    # Back end views for retrieving data
    # used in bundle/plugin page to add to update wishlist data in the database
    path('backend/add-to-favorites', views.add_favorites, name="add_favorites"),
    # used in bundle/plugin to update the button
    path('backend/set-favorites', views.setFavoritesButton, name="set_favorites"),
    # used in wishlist page to remove item from a users wishlist
    path('backend/remove-from-wishlist', views.remove_from_wishlist, name='remove_from_wishlist'),
    # used in wishlist page to add mark an item as purchased in the database
    path('backend/add-to-purchase', views.add_to_purchased, name='add_to_purchased'),
    # used in wishlist page updated the database that the user wants to be notifed when the price drops
    path('backend/send-notification', views.send_notification, name='send_notification'),
    # used to test the graph
    path('backend/test', views.dataview.as_view(), name='plugin charts'),
]
