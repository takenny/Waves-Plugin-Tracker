from django import template
from django.template.defaultfilters import stringfilter

register = template.Library()


@register.simple_tag()
def next_page(value):
    if 'page=' in value:
        new_value = value.split('page=')
        new_value[1] = str(int(new_value[1]) + 1)
        return new_value[0] + 'page=' + new_value[1]
    else:
        return value + '&page=2'


@register.simple_tag()
def prev_page(value):
    if 'page=' in value:
        new_value = value.split('page=')
        new_value[1] = str(int(new_value[1]) - 1)
        return new_value[0] + 'page=' + new_value[1]
    else:
        return value + '&page=1'


@register.simple_tag()
def to_page(value, num):
    if 'page=' in value:
        new_value = value.split('page=')
        new_value[1] = str(num)
        return new_value[0] + 'page=' + new_value[1]
    else:
        return value + '&page=' + str(num)
